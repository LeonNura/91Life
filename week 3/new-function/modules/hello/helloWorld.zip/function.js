exports.hello = (req, res) => {
  res.send('Hello, DITI!');
};
