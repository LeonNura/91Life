exports.api = (req, res) => {
  res.send('Hello, API!');
};
